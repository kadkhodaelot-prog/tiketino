package ir.ticketino.smsbridge;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.security.Principal;
import java.security.cert.Certificate;
import java.util.Locale;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLHandshakeException;

public final class BridgeClientRegression {
    private static final String SECRET = "fixture-secret-0123456789abcdef0123456789abcdef";
    private static int passed;
    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    private static final class FakeHttps extends HttpsURLConnection {
        final ByteArrayOutputStream written = new ByteArrayOutputStream();
        final int code;
        final byte[] response;
        boolean disconnected;
        int streamedLength;
        FakeHttps(int code, String body) throws Exception {
            super(new URL("https://example.invalid/ticketino/api/heartbeat"));
            this.code = code; this.response = body.getBytes(StandardCharsets.UTF_8);
        }
        @Override public void setFixedLengthStreamingMode(int length) { streamedLength = length; }
        @Override public OutputStream getOutputStream() { return written; }
        @Override public int getResponseCode() { return code; }
        @Override public InputStream getInputStream() throws IOException {
            if (code >= 400) throw new IOException("error responses must use the error stream");
            return new ByteArrayInputStream(response);
        }
        @Override public InputStream getErrorStream() {
            return code >= 400 ? new ByteArrayInputStream(response) : null;
        }
        @Override public long getHeaderFieldDate(String name, long defaultValue) { return 1234567890000L; }
        @Override public void disconnect() { disconnected = true; }
        @Override public boolean usingProxy() { return false; }
        @Override public void connect() { }
        @Override public String getCipherSuite() { return "test-only"; }
        @Override public Certificate[] getLocalCertificates() { return null; }
        @Override public Certificate[] getServerCertificates() { return new Certificate[0]; }
        @Override public Principal getPeerPrincipal() { return () -> "test"; }
        @Override public Principal getLocalPrincipal() { return () -> "test"; }
    }
    private static BridgeClient.Response send(FakeHttps connection, String payload) throws Exception {
        return BridgeClient.post("https://example.invalid/ticketino/", "fixture-device-1234", SECRET,
                "/api/heartbeat", payload, url -> {
                    check(url.toString().equals("https://example.invalid/ticketino/api/heartbeat"), "API prefix lost");
                    return connection;
                });
    }
    private static void goldenSignature(String expected) throws Exception {
        byte[] body = "{\"body\":\"واریز به حساب شما نشست\",\"pending\":0}".getBytes(StandardCharsets.UTF_8);
        check(BridgeClient.signature(SECRET, "1790942400", "fixture-nonce-12345678", body).equals(expected),
                "Java signature disagrees with independent Python HMAC");
        passed++;
    }
    private static void signedUtf8Request() throws Exception {
        Locale previous = Locale.getDefault();
        Locale.setDefault(Locale.forLanguageTag("fa-IR"));
        try {
            FakeHttps connection = new FakeHttps(200, "{\"status\":\"ok\"}");
            String payload = "{\"sms_permission\":true,\"description\":\"واریز\",\"pending\":0,\"review\":0}";
            BridgeClient.Response response = send(connection, payload);
            byte[] sent = connection.written.toByteArray();
            check(new String(sent, StandardCharsets.UTF_8).equals(payload), "UTF-8 payload changed");
            check(connection.streamedLength == sent.length, "Content-Length must count bytes");
            String stamp = connection.getRequestProperty("X-Sent-At");
            String nonce = connection.getRequestProperty("X-Nonce");
            check(stamp.matches("[0-9]+"), "Persian locale changed authentication timestamp");
            check(nonce.matches("[a-zA-Z0-9_-]{16,100}"), "Nonce rejected by backend rules");
            check(connection.getRequestProperty("X-Device-Id").equals("fixture-device-1234"), "Device header missing");
            check(connection.getRequestProperty("X-Signature").equals(BridgeClient.signature(SECRET, stamp, nonce, sent)),
                    "Signature does not cover exact sent bytes");
            check(connection.getRequestMethod().equals("POST"), "Wrong method");
            check(connection.getConnectTimeout() == 15000 && connection.getReadTimeout() == 15000, "Unbounded timeouts");
            check(!connection.getInstanceFollowRedirects(), "Credentials could follow redirects");
            check(!connection.getRequestProperties().toString().contains(SECRET), "Raw secret sent as header");
            check(response.successful() && response.body.equals("{\"status\":\"ok\"}") && connection.disconnected,
                    "Successful response was not read or connection leaked");
            check(response.serverTime == 1234567890000L, "Server date not retained");
            passed++;
        } finally { Locale.setDefault(previous); }
    }
    private static void errorResponse() throws Exception {
        FakeHttps connection = new FakeHttps(401, "{\"error\":\"authentication_failed\"}");
        BridgeClient.Response response = send(connection, "{}");
        check(!response.successful() && response.code == 401 && response.body.isEmpty(),
                "HTTP error response lost");
        check(connection.disconnected, "Error connection leaked");
        FakeHttps blocked = new FakeHttps(403, "x".repeat(BridgeClient.MAX_RESPONSE_BYTES + 1));
        check(send(blocked, "{}").code == 403 && blocked.disconnected, "Large HTML error hid HTTP code");
        passed++;
    }
    private static void boundedResponse() throws Exception {
        FakeHttps connection = new FakeHttps(200, "x".repeat(BridgeClient.MAX_RESPONSE_BYTES + 1));
        try { send(connection, "{}"); throw new AssertionError("Oversized response accepted"); }
        catch (BridgeClient.Failure expected) { check(connection.disconnected, "Oversized response leaked connection"); }
        FakeHttps exact = new FakeHttps(200, "x".repeat(BridgeClient.MAX_RESPONSE_BYTES));
        check(send(exact, "{}").body.length() == BridgeClient.MAX_RESPONSE_BYTES, "Response limit boundary wrong");
        passed++;
    }
    private static void rejectedUrl(String base) throws Exception {
        final boolean[] opened = {false};
        try {
            BridgeClient.post(base, "fixture-device-1234", SECRET, "/api/heartbeat", "{}", url -> {
                opened[0] = true; throw new IOException("should not connect");
            });
            throw new AssertionError("Unsafe endpoint accepted");
        } catch (BridgeClient.Failure expected) { check(!opened[0], "Unsafe endpoint opened"); }
        passed++;
    }
    private static void redirectAndHttpDiagnostics() throws Exception {
        FakeHttps redirected = new FakeHttps(302, "<html>redirect</html>");
        BridgeClient.Response response = send(redirected, "{}");
        check(response.code == 302 && !response.successful() && !redirected.getInstanceFollowRedirects(),
                "Redirect treated as success");
        check(BridgeClient.httpError(response).contains("HTTP 302"), "Redirect code hidden");
        for (int code : new int[]{401,403,404,422,429,500,503}) {
            String message = BridgeClient.httpError(new BridgeClient.Response(code, SECRET, 0, 0));
            check(message.contains("HTTP " + code) && !message.contains(SECRET), "Unsafe/missing HTTP diagnostic");
        }
        passed++;
    }
    private static void clockDiagnostics() {
        String skew = BridgeClient.httpError(new BridgeClient.Response(401, "{}", 2000000L, 1000000L));
        String aligned = BridgeClient.httpError(new BridgeClient.Response(401, "{}", 1000000L, 1000000L));
        check(skew.contains("۵ دقیقه") && aligned.contains("کلید"), "Clock and key failure indistinguishable");
        passed++;
    }
    private static void safeFailureDiagnostics() {
        Throwable[] errors = {new UnknownHostException(SECRET), new SocketTimeoutException(SECRET),
                new SSLHandshakeException(SECRET), new IOException(SECRET), new Exception(SECRET)};
        for (Throwable error : errors) {
            String text = BridgeClient.describe(new Exception("outer " + SECRET, error));
            check(!text.contains(SECRET) && !text.isEmpty(), "Sensitive exception leaked");
        }
        check(BridgeClient.describe(errors[0]).contains("دامنه"), "DNS cause hidden");
        check(BridgeClient.describe(errors[1]).contains("مهلت"), "Timeout cause hidden");
        check(BridgeClient.describe(errors[2]).contains("HTTPS"), "TLS cause hidden");
        passed++;
    }
    public static void main(String[] args) throws Exception {
        goldenSignature(args[0]); signedUtf8Request(); errorResponse(); boundedResponse();
        rejectedUrl("http://example.invalid/ticketino");
        rejectedUrl("https://user:password@example.invalid/ticketino");
        rejectedUrl("https://example.invalid/ticketino?token=sensitive");
        rejectedUrl("https://example.invalid/ticketino#sensitive");
        redirectAndHttpDiagnostics(); clockDiagnostics(); safeFailureDiagnostics();
        System.out.println("PASS: " + passed + " signed transport regression cases (fake HTTPS transport; no phone/APK test).");
    }
}
