#!/usr/bin/env python3
"""Compile production HTTPS client and run independent HMAC/transport checks on JDK 17."""
import hashlib
import hmac
import pathlib
import subprocess
import tempfile

project = pathlib.Path(__file__).resolve().parent.parent
client = project / "android/app/src/main/java/ir/ticketino/smsbridge/BridgeClient.java"
test = project / "tests/BridgeClientRegression.java"
secret = b"fixture-secret-0123456789abcdef0123456789abcdef"
body = '{"body":"واریز به حساب شما نشست","pending":0}'.encode("utf-8")
material = ("1790942400" + "\n" + "fixture-nonce-12345678" + "\n" + hashlib.sha256(body).hexdigest()).encode("utf-8")
expected = hmac.new(secret, material, hashlib.sha256).hexdigest()
with tempfile.TemporaryDirectory(prefix="ticketino-java-check-") as out:
    subprocess.run(["java", "--module", "jdk.compiler/com.sun.tools.javac.Main", "-encoding", "UTF-8",
                    "--release", "17", "-Xlint:all", "-d", out, str(client), str(test)], check=True)
    subprocess.run(["java", "-cp", out, "ir.ticketino.smsbridge.BridgeClientRegression", expected], check=True)
