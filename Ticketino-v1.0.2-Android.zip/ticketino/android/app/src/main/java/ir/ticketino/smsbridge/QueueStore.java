package ir.ticketino.smsbridge;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public final class QueueStore extends SQLiteOpenHelper {
    public static final class Item {
        public long id; public String payload; public String pairing;
    }
    public QueueStore(Context context) { super(context, "outgoing.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE queue(id INTEGER PRIMARY KEY AUTOINCREMENT,event_id TEXT UNIQUE NOT NULL,payload TEXT NOT NULL,pairing TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'pending',created_at INTEGER NOT NULL)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
    public synchronized void add(String event, String payload, String pairing) throws Exception {
        ContentValues values = new ContentValues();
        values.put("event_id", event); values.put("payload", Vault.encrypt(payload));
        values.put("pairing", Vault.encrypt(pairing)); values.put("created_at", System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("queue", null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }
    public List<Item> pending() throws Exception {
        List<Item> items = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().rawQuery("SELECT id,payload,pairing FROM queue WHERE state='pending' ORDER BY id LIMIT 30", null)) {
            while (cursor.moveToNext()) {
                Item item = new Item(); item.id = cursor.getLong(0);
                item.payload = Vault.decrypt(cursor.getString(1)); item.pairing = Vault.decrypt(cursor.getString(2));
                items.add(item);
            }
        }
        return items;
    }
    public void sent(long id) { getWritableDatabase().delete("queue", "id=?", new String[]{Long.toString(id)}); }
    public void review(long id) { ContentValues v = new ContentValues(); v.put("state", "review"); getWritableDatabase().update("queue", v, "id=?", new String[]{Long.toString(id)}); }
    public int count(String state) { try (Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM queue WHERE state=?", new String[]{state})) { c.moveToFirst(); return c.getInt(0); } }
}
