package ir.ticketino.smsbridge;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import org.json.JSONObject;

final class BridgeConnection {
    static BridgeClient.Response post(JSONObject config, String path, String payload) throws Exception {
        return BridgeClient.post(config.getString("url"), config.getString("device_id"),
                config.getString("secret"), path, payload);
    }
    static void requireAck(BridgeClient.Response response, String... expected) throws Exception {
        if (!response.successful()) throw new BridgeClient.Failure(BridgeClient.httpError(response));
        try {
            String status = new JSONObject(response.body).optString("status", "");
            for (String value : expected) if (value.equals(status)) return;
        } catch (org.json.JSONException ignored) { }
        throw new BridgeClient.Failure("پاسخ معتبر از API دریافت نشد؛ نشانی اتصال و مسیر /ticketino را بررسی کنید.");
    }
    static void heartbeat(Context context, String pairing) throws Exception {
        JSONObject config = new JSONObject(pairing);
        JSONObject heartbeat = new JSONObject();
        heartbeat.put("sms_permission", context.checkSelfPermission(Manifest.permission.RECEIVE_SMS)
                == PackageManager.PERMISSION_GRANTED);
        try (QueueStore queue = new QueueStore(context)) {
            heartbeat.put("pending", queue.count("pending"));
            heartbeat.put("review", queue.count("review"));
        }
        requireAck(post(config, "/api/heartbeat", heartbeat.toString()), "ok");
        if (pairing.equals(Vault.pairing(context))) {
            context.getSharedPreferences("bridge", Context.MODE_PRIVATE).edit()
                    .putLong("last_sync", System.currentTimeMillis()).putString("last_error", "").apply();
        }
    }
    static void begin(Context context, String pairing) throws Exception {
        if (pairing.equals(Vault.pairing(context))) {
            context.getSharedPreferences("bridge", Context.MODE_PRIVATE).edit()
                    .putLong("last_attempt", System.currentTimeMillis()).putString("last_error", "").apply();
        }
    }
    static void failed(Context context, String pairing, Exception exception) {
        try {
            if (pairing.equals(Vault.pairing(context))) {
                context.getSharedPreferences("bridge", Context.MODE_PRIVATE).edit()
                        .putString("last_error", BridgeClient.describe(exception)).apply();
            }
        } catch (Exception ignored) { }
    }
}
