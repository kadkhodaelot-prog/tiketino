package ir.ticketino.smsbridge;

import android.content.Context;
import androidx.work.*;
import java.util.concurrent.TimeUnit;

public final class BridgeWork {
    public static void schedule(Context context) {
        Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(UploadWorker.class, 15, TimeUnit.MINUTES)
                .setConstraints(constraints).setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build();
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("ticketino-heartbeat", ExistingPeriodicWorkPolicy.KEEP, request);
        now(context);
    }
    public static void now(Context context) {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(UploadWorker.class)
                .setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build();
        // Automatic SMS arrivals share one job; avoid a delayed chain.
        WorkManager.getInstance(context).enqueueUniqueWork("ticketino-upload", ExistingWorkPolicy.KEEP, request);
    }
    public static void forceNow(Context context) {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(UploadWorker.class)
                .setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build();
        // Bypass an older retry/backoff after the foreground check succeeds.
        // Cancelling work leaves the encrypted outgoing.db SMS queue intact.
        WorkManager.getInstance(context).enqueueUniqueWork("ticketino-upload", ExistingWorkPolicy.REPLACE, request);
    }
}
