package ir.ticketino.smsbridge;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private TextView status;
    private EditText pairing;
    private Button connectButton, retryButton;
    private boolean checkingConnection;
    private final ExecutorService connectionExecutor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler();
    private final Runnable refresh = new Runnable() { @Override public void run() { updateStatus(); handler.postDelayed(this, 3000); } };
    private final int teal = Color.rgb(0,108,128), ink = Color.rgb(24,60,69);
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private TextView label(String text, int size, boolean bold) {
        TextView view = new TextView(this); view.setText(text); view.setTextSize(size); view.setTextColor(ink);
        view.setPadding(0, dp(8), 0, dp(8)); view.setLineSpacing(dp(3),1);
        if (bold) view.setTypeface(null, Typeface.BOLD);
        return view;
    }
    private Button action(LinearLayout root, String title, View.OnClickListener listener) {
        Button button = new Button(this); button.setText(title); button.setTextColor(Color.WHITE); button.setTextSize(15); button.setAllCaps(false);
        GradientDrawable background = new GradientDrawable(); background.setColor(teal); background.setCornerRadius(dp(12)); button.setBackground(background);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(54)); params.topMargin = dp(12);
        root.addView(button,params); button.setOnClickListener(listener);
        return button;
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(Color.rgb(243,248,250));
        scroll.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(24),dp(22),dp(24),dp(30)); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root); setContentView(scroll);
        root.addView(label("اتصال پیامک بلیط",26,true));
        root.addView(label("این برنامه روی گوشی دریافت‌کننده پیامک واریز نصب می‌شود. رسیدگی به خریدها از پنل تلگرام انجام می‌شود.",15,false));
        status = label("در حال بررسی وضعیت…",15,true); status.setPadding(dp(16),dp(16),dp(16),dp(16));
        GradientDrawable panel = new GradientDrawable(); panel.setColor(Color.WHITE); panel.setCornerRadius(dp(16)); status.setBackground(panel); root.addView(status);
        root.addView(label("تنظیمات اتصال",18,true));
        root.addView(label("در ربات: پنل مدیریت ← گوشی پیامک ← اتصال گوشی جدید. متن اتصال را کپی و اینجا وارد کنید.",14,false));
        pairing = new EditText(this); pairing.setMinLines(4); pairing.setMaxLines(6); pairing.setTextSize(13); pairing.setGravity(Gravity.TOP|Gravity.LEFT); pairing.setLayoutDirection(View.LAYOUT_DIRECTION_LTR); pairing.setTextDirection(View.TEXT_DIRECTION_LTR); pairing.setHint("{\"url\":\"https://…\",\"device_id\":\"…\",\"secret\":\"…\",\"sender\":\"…\"}"); root.addView(pairing);
        action(root,"چسباندن تنظیمات از حافظه", v -> {
            ClipboardManager clipboard = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            if (clipboard.hasPrimaryClip() && clipboard.getPrimaryClip().getItemCount()>0) pairing.setText(clipboard.getPrimaryClip().getItemAt(0).coerceToText(this));
        });
        connectButton = action(root,"ذخیره و اتصال", v -> save());
        action(root,"فعال‌کردن دریافت پیامک", v -> requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS},10));
        retryButton = action(root,"بررسی اتصال و تلاش دوباره", v -> checkConnection());
        action(root,"تنظیم مصرف باتری", v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()))));
        root.addView(label("فقط پیام واریز از فرستنده تنظیم‌شده ارسال می‌شود. رمز پویا و پیامک‌های دیگر ارسال نمی‌شوند. تنظیمات اتصال و صف پیام‌ها در گوشی رمزگذاری می‌شوند.",13,false));
        root.addView(label("برای کارکرد پس‌زمینه، مجوز پیامک را فعال و مصرف باتری برنامه را روی «بدون محدودیت» تنظیم کنید. توقف اجباری برنامه، دریافت پیامک را متوقف می‌کند تا دوباره آن را باز کنید.",13,false));
        root.addView(label("نسخه ۱.۰.۲",12,false));
    }
    private void save() {
        try {
            JSONObject value = new JSONObject(pairing.getText().toString().trim());
            String urlText = value.getString("url").replaceAll("/+$", ""); URL url = new URL(urlText);
            if (!url.getProtocol().equals("https") || url.getHost().isEmpty() || url.getUserInfo()!=null || url.getQuery()!=null || url.getRef()!=null) throw new Exception();
            if (!value.getString("device_id").matches("[a-zA-Z0-9_-]{8,80}") || value.getString("secret").length()<32 || !BankReceiver.phone(value.getString("sender")).matches("\\+[1-9][0-9]{7,14}")) throw new Exception();
            value.put("url",urlText); value.put("sender",BankReceiver.phone(value.getString("sender")));
            Vault.savePairing(this,value.toString()); pairing.setText("");
            ClipboardManager clipboard = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE); clipboard.setPrimaryClip(ClipData.newPlainText("", ""));
            getSharedPreferences("bridge",Context.MODE_PRIVATE).edit().putLong("last_sync",0)
                    .putLong("last_attempt",0).putString("last_error","").apply();
            BridgeWork.schedule(this); updateStatus(); checkConnection();
        } catch (Exception exception) { new AlertDialog.Builder(this).setMessage("متن اتصال معتبر نیست. تنظیمات کامل را از پنل مدیر کپی کنید.").setPositiveButton("باشه",null).show(); }
    }
    private void checkConnection() {
        if (checkingConnection) return;
        final Context app = getApplicationContext();
        final String savedPairing;
        try {
            savedPairing = Vault.pairing(app);
            if (savedPairing.isEmpty()) {
                new AlertDialog.Builder(this).setMessage("ابتدا متن اتصال را از پنل مدیر وارد و ذخیره کنید.")
                        .setPositiveButton("باشه",null).show();
                return;
            }
        } catch (Exception exception) {
            new AlertDialog.Builder(this).setMessage("تنظیمات اتصال قابل خواندن نیست؛ متن اتصال را دوباره وارد کنید.")
                    .setPositiveButton("باشه",null).show();
            return;
        }
        checkingConnection = true;
        connectButton.setEnabled(false); retryButton.setEnabled(false);
        retryButton.setText("در حال بررسی اتصال…"); updateStatus();
        // Foreground checks run directly; WorkManager backoff cannot delay them.
        connectionExecutor.execute(() -> {
            String result;
            boolean connected = false;
            try {
                BridgeConnection.begin(app, savedPairing);
                BridgeConnection.heartbeat(app, savedPairing);
                if (savedPairing.equals(Vault.pairing(app))) {
                    BridgeWork.forceNow(app);
                    connected = true;
                    result = "اتصال به سرور برقرار شد؛ ارسال پیام‌های باقی‌مانده شروع می‌شود.";
                } else result = "تنظیمات اتصال تغییر کرده است؛ دوباره اتصال را بررسی کنید.";
            } catch (Exception exception) {
                result = BridgeClient.describe(exception);
                BridgeConnection.failed(app, savedPairing, exception);
            }
            final String message = result;
            final boolean success = connected;
            handler.post(() -> {
                if (isDestroyed() || isFinishing()) return;
                checkingConnection = false;
                connectButton.setEnabled(true); retryButton.setEnabled(true);
                retryButton.setText("بررسی اتصال و تلاش دوباره"); updateStatus();
                if (success) Toast.makeText(this,message,Toast.LENGTH_LONG).show();
                else new AlertDialog.Builder(this).setTitle("نتیجه بررسی اتصال").setMessage(message)
                        .setPositiveButton("باشه",null).show();
            });
        });
    }
    private String stamp(long value) { return value==0 ? "ثبت نشده" : new SimpleDateFormat("yyyy/MM/dd HH:mm",Locale.getDefault()).format(new Date(value)); }
    private void updateStatus() {
        if (status==null) return;
        try (QueueStore queue = new QueueStore(this)) {
            String config = Vault.pairing(this);
            android.content.SharedPreferences prefs = getSharedPreferences("bridge",Context.MODE_PRIVATE);
            status.setText("اتصال: " + (checkingConnection?"در حال بررسی…":config.isEmpty()?"تنظیم نشده":"تنظیم‌شده") + "\nمجوز پیامک: " + (checkSelfPermission(Manifest.permission.RECEIVE_SMS)==PackageManager.PERMISSION_GRANTED?"فعال":"نیاز به فعال‌سازی") + "\nدر صف ارسال: " + queue.count("pending") + "\nنیازمند بررسی: " + queue.count("review") + "\nآخرین پیام واریز: " + stamp(prefs.getLong("last_received",0)) + "\nآخرین اتصال موفق: " + stamp(prefs.getLong("last_sync",0)) + "\nآخرین تلاش اتصال: " + stamp(prefs.getLong("last_attempt",0)) + "\n" + prefs.getString("last_error",""));
        } catch (Exception exception) { status.setText("تنظیمات اتصال قابل خواندن نیست؛ اتصال را دوباره وارد کنید."); }
    }
    @Override protected void onResume() { super.onResume(); BridgeWork.schedule(this); handler.post(refresh); }
    @Override protected void onPause() { handler.removeCallbacks(refresh); super.onPause(); }
    @Override protected void onDestroy() { connectionExecutor.shutdownNow(); super.onDestroy(); }
}
