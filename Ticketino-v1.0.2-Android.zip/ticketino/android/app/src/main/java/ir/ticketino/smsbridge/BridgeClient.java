package ir.ticketino.smsbridge;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLException;

/** Signed HTTPS transport shared by the foreground check and background upload. */
final class BridgeClient {
    static final int TIMEOUT_MS = 15000;
    static final int MAX_RESPONSE_BYTES = 8192;
    interface ConnectionFactory { HttpsURLConnection open(URL url) throws IOException; }

    static final class Response {
        final int code;
        final String body;
        final long serverTime;
        final long receivedAt;
        Response(int code, String body, long serverTime, long receivedAt) {
            this.code = code; this.body = body; this.serverTime = serverTime; this.receivedAt = receivedAt;
        }
        boolean successful() { return code >= 200 && code < 300; }
    }
    static final class Failure extends IOException {
        private static final long serialVersionUID = 1L;
        Failure(String safeMessage) { super(safeMessage); }
    }
    static String hex(byte[] bytes) {
        StringBuilder result = new StringBuilder(bytes.length * 2);
        for (byte value : bytes) {
            result.append(Character.forDigit((value >>> 4) & 15, 16));
            result.append(Character.forDigit(value & 15, 16));
        }
        return result.toString();
    }
    static String sha256(byte[] bytes) throws Exception {
        return hex(MessageDigest.getInstance("SHA-256").digest(bytes));
    }
    static String signature(String secret, String timestamp, String nonce, byte[] body) throws Exception {
        String material = timestamp + "\n" + nonce + "\n" + sha256(body);
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return hex(mac.doFinal(material.getBytes(StandardCharsets.UTF_8)));
    }
    static Response post(String base, String deviceId, String secret, String path, String payload) throws Exception {
        return post(base, deviceId, secret, path, payload,
                url -> (HttpsURLConnection) url.openConnection());
    }
    static Response post(String base, String deviceId, String secret, String path, String payload,
                         ConnectionFactory factory) throws Exception {
        URL endpoint = new URL(base.replaceAll("/+$", "") + path);
        if (!endpoint.getProtocol().equals("https") || endpoint.getHost().isEmpty()
                || endpoint.getUserInfo() != null || endpoint.getQuery() != null || endpoint.getRef() != null
                || !(path.equals("/api/heartbeat") || path.equals("/api/sms"))) {
            throw new Failure("نشانی اتصال معتبر نیست؛ متن اتصال را دوباره از پنل مدیر وارد کنید.");
        }
        if (!deviceId.matches("[a-zA-Z0-9_-]{8,80}") || secret.length() < 32) {
            throw new Failure("تنظیمات اتصال ناقص است؛ متن اتصال را دوباره از پنل مدیر وارد کنید.");
        }
        byte[] body = payload.getBytes(StandardCharsets.UTF_8);
        String timestamp = Long.toString(System.currentTimeMillis() / 1000);
        String nonce = UUID.randomUUID().toString();
        String signed = signature(secret, timestamp, nonce, body);
        HttpsURLConnection connection = factory.open(endpoint);
        try {
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(TIMEOUT_MS);
            connection.setReadTimeout(TIMEOUT_MS);
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setFixedLengthStreamingMode(body.length);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("X-Device-Id", deviceId);
            connection.setRequestProperty("X-Sent-At", timestamp);
            connection.setRequestProperty("X-Nonce", nonce);
            connection.setRequestProperty("X-Signature", signed);
            try (OutputStream stream = connection.getOutputStream()) { stream.write(body); }
            int code = connection.getResponseCode();
            long serverTime = connection.getHeaderFieldDate("Date", 0);
            if (code < 200 || code >= 300) {
                // Error pages can be large HTML. Preserve the HTTP code without
                // trusting or reading their content, including redirect bodies.
                InputStream error = connection.getErrorStream();
                if (error != null) try { error.close(); } catch (IOException ignored) { }
                return new Response(code, "", serverTime, System.currentTimeMillis());
            }
            return new Response(code, readResponse(connection.getInputStream()), serverTime, System.currentTimeMillis());
        } finally { connection.disconnect(); }
    }
    private static String readResponse(InputStream stream) throws IOException {
        if (stream == null) return "";
        try (InputStream input = stream; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[1024];
            int count;
            while ((count = input.read(buffer)) != -1) {
                if (output.size() + count > MAX_RESPONSE_BYTES) {
                    throw new Failure("پاسخ API سرور معتبر نیست؛ نشانی اتصال و تنظیمات سرور را بررسی کنید.");
                }
                output.write(buffer, 0, count);
            }
            return new String(output.toByteArray(), StandardCharsets.UTF_8);
        }
    }
    static String httpError(Response response) {
        String code = " (HTTP " + response.code + ")";
        if (response.code == 401) {
            if (response.serverTime > 0 && Math.abs(response.serverTime - response.receivedAt) > 300000L) {
                return "ساعت گوشی با سرور بیش از ۵ دقیقه اختلاف دارد؛ تاریخ و ساعت خودکار را فعال کنید." + code;
            }
            return "سرور اتصال را تأیید نکرد؛ کلید اتصال یا ساعت گوشی را بررسی کنید. اگر کلید لغو شده، اتصال جدید بسازید." + code;
        }
        if (response.code >= 300 && response.code < 400) {
            return "سرور درخواست را به نشانی دیگری هدایت کرد؛ نشانی کامل اتصال را از پنل مدیر وارد کنید." + code;
        }
        if (response.code == 404) return "مسیر API پیدا نشد؛ نشانی اتصال و مسیر /ticketino را بررسی کنید." + code;
        if (response.code == 403) return "دسترسی برنامه توسط سرور یا تنظیمات هاست رد شد." + code;
        if (response.code == 422) return "سرور محتوای درخواست را نپذیرفت؛ نسخه برنامه و سرور را بررسی کنید." + code;
        if (response.code == 429) return "تعداد درخواست‌ها زیاد است؛ کمی بعد دوباره تلاش کنید." + code;
        if (response.code >= 500) return "سرور پاسخ خطا داد؛ سرویس و لاگ سرور را بررسی کنید." + code;
        return "درخواست اتصال پذیرفته نشد." + code;
    }
    static String describe(Throwable exception) {
        for (Throwable cause = exception; cause != null; cause = cause.getCause()) {
            if (cause instanceof Failure) return cause.getMessage();
            if (cause instanceof UnknownHostException) return "نام دامنه پیدا نشد؛ اینترنت، DNS و نشانی اتصال را بررسی کنید.";
            if (cause instanceof SocketTimeoutException) return "مهلت پاسخ سرور تمام شد؛ اینترنت یا دسترسی سرور را بررسی و دوباره تلاش کنید.";
            if (cause instanceof SSLException) return "اتصال امن HTTPS برقرار نشد؛ تاریخ گوشی و گواهی SSL سرور را بررسی کنید.";
        }
        // Never expose exception messages, which may contain pairing or SMS data.
        return "اتصال کامل نشد؛ اینترنت و تنظیمات اتصال را بررسی و دوباره تلاش کنید.";
    }
}
