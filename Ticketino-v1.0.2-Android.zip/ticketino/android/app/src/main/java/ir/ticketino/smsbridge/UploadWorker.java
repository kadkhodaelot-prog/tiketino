package ir.ticketino.smsbridge;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONObject;

public final class UploadWorker extends Worker {
    public UploadWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }
    public static String sha256(byte[] bytes) throws Exception { return BridgeClient.sha256(bytes); }

    @NonNull @Override public Result doWork() {
        Context context = getApplicationContext();
        String current = "";
        try {
            current = Vault.pairing(context);
            if (current.isEmpty()) return Result.success();
            JSONObject config = new JSONObject(current);
            BridgeConnection.begin(context, current);
            // Check the active connection even when old SMS items need review.
            BridgeConnection.heartbeat(context, current);
            try (QueueStore queue = new QueueStore(context)) {
                for (QueueStore.Item item : queue.pending()) {
                    if (isStopped() || !current.equals(Vault.pairing(context))) return Result.success();
                    JSONObject itemConfig = new JSONObject(item.pairing);
                    BridgeClient.Response response = BridgeConnection.post(itemConfig, "/api/sms", item.payload);
                    if (response.code == 422 || (response.code == 401
                            && !itemConfig.getString("device_id").equals(config.getString("device_id")))) {
                        queue.review(item.id);
                    } else {
                        // HTML, an empty 200, or an unknown status must never delete an SMS.
                        BridgeConnection.requireAck(response, "accepted", "duplicate");
                        queue.sent(item.id);
                    }
                }
                if (queue.count("pending") > 0) return Result.retry();
            }
            return Result.success();
        } catch (Exception exception) {
            BridgeConnection.failed(context, current, exception);
            return Result.retry();
        }
    }
}
