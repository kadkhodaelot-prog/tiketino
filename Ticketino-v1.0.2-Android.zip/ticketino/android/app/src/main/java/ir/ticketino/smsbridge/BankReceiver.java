package ir.ticketino.smsbridge;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import org.json.JSONObject;

public final class BankReceiver extends BroadcastReceiver {
    public static String phone(String value) {
        value = value.replaceAll("[\\s()-]", "");
        if (value.startsWith("0098")) value = "+98" + value.substring(4);
        if (value.startsWith("0") && value.length() == 11) value = "+98" + value.substring(1);
        return value;
    }
    @Override public void onReceive(Context context, Intent intent) {
        if (!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        PendingResult result = goAsync();
        new Thread(() -> {
            try {
                String pairing = Vault.pairing(context);
                if (pairing.isEmpty()) return;
                JSONObject config = new JSONObject(pairing);
                SmsMessage[] messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
                if (messages.length == 0) return;
                String sender = phone(messages[0].getOriginatingAddress() == null ? "" : messages[0].getOriginatingAddress());
                if (!sender.equals(phone(config.getString("sender")))) return;
                StringBuilder body = new StringBuilder();
                for (SmsMessage message : messages) {
                    if (!phone(message.getOriginatingAddress() == null ? "" : message.getOriginatingAddress()).equals(sender)) return;
                    body.append(message.getMessageBody());
                }
                String text = body.toString();
                // Send only the specified incoming deposit format. Never relay OTP or unrelated messages.
                if (!text.contains("به حساب شما نشست") || !text.contains("ریال")) return;
                long received = messages[0].getTimestampMillis() / 1000;
                String event = UploadWorker.sha256((sender + "|" + received + "|" + text).getBytes(java.nio.charset.StandardCharsets.UTF_8));
                JSONObject payload = new JSONObject();
                payload.put("event_id", event); payload.put("sender", sender); payload.put("body", text); payload.put("received_at", received);
                try (QueueStore queue = new QueueStore(context)) { queue.add(event, payload.toString(), pairing); }
                context.getSharedPreferences("bridge", Context.MODE_PRIVATE).edit().putLong("last_received", System.currentTimeMillis()).apply();
                BridgeWork.schedule(context);
            } catch (Exception exception) {
                context.getSharedPreferences("bridge", Context.MODE_PRIVATE).edit().putString("last_error", "ذخیره پیامک کامل نشد؛ تنظیمات اتصال را بررسی کنید.").apply();
            } finally { result.finish(); }
        }).start();
    }
}
