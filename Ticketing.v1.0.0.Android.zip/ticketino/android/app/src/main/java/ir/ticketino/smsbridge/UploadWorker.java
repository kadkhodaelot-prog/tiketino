package ir.ticketino.smsbridge;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;
import java.net.URL;
import java.io.OutputStream;
import javax.net.ssl.HttpsURLConnection;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.json.JSONObject;

public final class UploadWorker extends Worker {
    public UploadWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }
    public static String hex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte value : bytes) result.append(String.format(java.util.Locale.ROOT, "%02x", value & 255));
        return result.toString();
    }
    public static String sha256(byte[] bytes) throws Exception { return hex(MessageDigest.getInstance("SHA-256").digest(bytes)); }
    private int post(JSONObject config, String path, String payload) throws Exception {
        URL url = new URL(config.getString("url") + path);
        if (!url.getProtocol().equals("https") || url.getUserInfo() != null) throw new Exception("HTTPS required");
        byte[] body = payload.getBytes(StandardCharsets.UTF_8);
        String timestamp = Long.toString(System.currentTimeMillis() / 1000);
        String nonce = UUID.randomUUID().toString();
        String material = timestamp + "\n" + nonce + "\n" + sha256(body);
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(config.getString("secret").getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        try {
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(15000); connection.setReadTimeout(15000);
            connection.setRequestMethod("POST"); connection.setDoOutput(true); connection.setFixedLengthStreamingMode(body.length);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("X-Device-Id", config.getString("device_id"));
            connection.setRequestProperty("X-Sent-At", timestamp); connection.setRequestProperty("X-Nonce", nonce);
            connection.setRequestProperty("X-Signature", hex(mac.doFinal(material.getBytes(StandardCharsets.UTF_8))));
            try (OutputStream stream = connection.getOutputStream()) { stream.write(body); }
            return connection.getResponseCode();
        } finally { connection.disconnect(); }
    }
    @NonNull @Override public Result doWork() {
        Context context = getApplicationContext();
        try {
            String current = Vault.pairing(context);
            if (current.isEmpty()) return Result.success();
            JSONObject config = new JSONObject(current);
            try (QueueStore queue = new QueueStore(context)) {
                for (QueueStore.Item item : queue.pending()) {
                    int code = post(new JSONObject(item.pairing), "/api/sms", item.payload);
                    if (code >= 200 && code < 300) queue.sent(item.id);
                    else if (code == 422 || (code == 401 && !new JSONObject(item.pairing).getString("device_id").equals(config.getString("device_id")))) queue.review(item.id);
                    else {
                        context.getSharedPreferences("bridge", Context.MODE_PRIVATE).edit().putString("last_error", code == 401 ? "کلید اتصال نامعتبر یا لغو شده است؛ اتصال گوشی را بررسی کنید." : "ارسال کامل نشد؛ دوباره تلاش می‌شود.").apply();
                        return Result.retry();
                    }
                }
                JSONObject heartbeat = new JSONObject();
                heartbeat.put("sms_permission", context.checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED);
                heartbeat.put("pending", queue.count("pending")); heartbeat.put("review", queue.count("review"));
                int code = post(config, "/api/heartbeat", heartbeat.toString());
                if (code < 200 || code >= 300) return Result.retry();
                context.getSharedPreferences("bridge", Context.MODE_PRIVATE).edit().putLong("last_sync", System.currentTimeMillis()).putString("last_error", "").apply();
                if (queue.count("pending") > 0) return Result.retry();
            }
            return Result.success();
        } catch (Exception exception) {
            context.getSharedPreferences("bridge", Context.MODE_PRIVATE).edit().putString("last_error", "اتصال برقرار نشد؛ اینترنت، ساعت گوشی و تنظیمات را بررسی کنید.").apply();
            return Result.retry();
        }
    }
}
