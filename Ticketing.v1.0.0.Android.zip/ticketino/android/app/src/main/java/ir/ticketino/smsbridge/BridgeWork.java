package ir.ticketino.smsbridge;

import android.content.Context;
import androidx.work.*;
import java.util.concurrent.TimeUnit;

public final class BridgeWork {
    public static void schedule(Context context) {
        Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(UploadWorker.class, 15, TimeUnit.MINUTES)
                .setConstraints(constraints).setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build();
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("ticketino-heartbeat", ExistingPeriodicWorkPolicy.KEEP, request);
        now(context);
    }
    public static void now(Context context) {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(UploadWorker.class)
                .setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build();
        WorkManager.getInstance(context).enqueueUniqueWork("ticketino-upload", ExistingWorkPolicy.APPEND_OR_REPLACE, request);
    }
}
